#!/usr/bin/python

import os;
import time;

class Include_types_test(boost_build_system.tester):

    def test(self):
	"Test if different styles of includes are correctly recognized."

	if os.name == 'posix':
	    ext = ""
	elif os.name == 'nt':
	    ext = ".exe"
	else:
	    raise "Don't know exe suffix for this platform."		    		    

	self.rebuild()
	time.sleep(3)
	# include <b.h> in src/a.h should be resolved to include/b.h
	self.touch("include/b.h")
	self.rebuild()
    	self.expect_touch("build/bin/main/" + toolset + "/debug/runtime-link-dynamic/main" + ext)
	time.sleep(3)
	self.touch("src/c.h")
	self.rebuild()
	self.expect_touch("build/bin/main/" + toolset + "/debug/runtime-link-dynamic/main" + ext)

