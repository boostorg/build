
import string;

class Bcc_library_test(boost_build_system.tester):

	toolsets = ["borland"]

	def test(self):
		"Test if library is updated as expected on borland."
		self.rebuild()
		self.set_content("c.cpp", "int n = 10;\n")
		self.rebuild()
		self.run("build/bin/main/borland/debug/runtime-link-dynamic/main.exe") 
		self.failUnless(string.strip(self.output[0]) == "10", "Object was not added to library.")
