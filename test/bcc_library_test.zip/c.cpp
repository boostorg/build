
int n = 2;