
extern int n;

#include <iostream>

int main()
{
	std::cout << n << "\n";
}