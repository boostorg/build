

class Subdir_invocation_test(boost_build_system.tester):

    def test(self):
        "Test if build is performed in the same way when invoked from a subdir."

	if os.name == 'posix':
    	    ext = ""
        elif os.name == 'nt':
	    ext = ".exe"
        else:
	    raise "Don't know exe suffix."			    

        self.rebuild("subdir")
	self.expect_addition("build/subdir/bin/main2/" + toolset + "/debug/runtime-link-dynamic/main2" + ext)
