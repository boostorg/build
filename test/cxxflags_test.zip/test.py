
from __future__ import nested_scopes;

import re;

class Cxxflags_features_test(boost_build_system.tester):

	def test(self):
		"Test for <cflags> and <cxxflags> features."
		self.rebuild(commands_only=1)
		re1 = re.compile(".*main1.c")
		re2 = re.compile(".*main2.cpp")
		c_line = filter(lambda x: re1.match(x) != None, self.commands)[0]
		cxx_line = filter(lambda x: re2.match(x) != None, self.commands)[0]
		self.failUnless(string.find(c_line, "-K") != -1, "Expect -K option in C compilation options")
		self.failUnless(string.find(cxx_line, "-Jgx") != -1, "Expect -Jgx option in C++ compilation options.")
