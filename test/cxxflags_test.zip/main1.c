
int main() {}
