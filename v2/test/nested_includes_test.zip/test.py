
class Nested_includes_test(boost_build_system.tester):

    def test(self):
	"Test if nested includes are correctly tracked."
	
	if os.name == 'posix':
	    ext = ""
	elif os.name == 'nt':
	    ext = ".exe"	    

	self.rebuild()
	print "I'll take a nap now, intentionally" 
	time.sleep(3)
	self.touch("include/include2/b.h")
	self.rebuild()
	self.expect_touch("build/bin/main/" + toolset + "/debug/runtime-link-dynamic/main" + ext)


